<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('api_keys', function (Blueprint $table): void {
            $table->id(); $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('name', 100); $table->string('prefix', 20); $table->string('key_hash', 64)->unique();
            $table->timestamp('last_used_at')->nullable(); $table->timestamp('revoked_at')->nullable(); $table->timestamps();
            $table->index(['user_id', 'revoked_at']);
        });
    }
    public function down(): void { Schema::dropIfExists('api_keys'); }
};
